# imagem_processing

Description.  
O pacote image_processing é usado para:  
    processing:
        - Histogram matching
        - Structural similarity
        - Resize image
    utils:
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot histogram

## Installation

Use o pacote gerenciador [pip](https://pip.pypa.io/en/stable/) para instalar package_name

```bash
pip install image_processing
```

## Autor
Roberto (forked from Karina Kato)